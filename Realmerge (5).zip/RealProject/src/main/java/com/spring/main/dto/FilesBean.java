package com.spring.main.dto;

public class FilesBean {
	
	private int fileIdx;
	private String oldfile;
	private String newfile;
	private int idx;
	private int seq;
	
	public int getFileIdx() {
		return fileIdx;
	}
	public void setFileIdx(int fileIdx) {
		this.fileIdx = fileIdx;
	}
	public String getOldfile() {
		return oldfile;
	}
	public void setOldfile(String oldFile) {
		this.oldfile = oldFile;
	}
	public String getNewfile() {
		return newfile;
	}
	public void setNewfile(String newFile) {
		this.newfile = newFile;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	
	

}
